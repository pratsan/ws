/**
 * 
 */
package com.star.savingsaccount.exception;

/**
 * @author User1
 *
 */
public class NotInaRangeException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4149095831099164083L;

	public NotInaRangeException(String message) {
		super(message);
	}

}
