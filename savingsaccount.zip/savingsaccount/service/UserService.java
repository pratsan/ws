/**
 * 
 */
package com.star.savingsaccount.service;

import com.star.savingsaccount.dto.ResponseDto;
import com.star.savingsaccount.dto.UserDto;

/**
 * @author User1
 *
 */
public interface UserService {
	
	public ResponseDto userLogin(UserDto userDto);

}
