/**
 * 
 */
package com.star.savingsaccount.dto;

/**
 * @author User1
 *
 */
public enum TransactionType {
	
	CREDIT, DEBIT

}
